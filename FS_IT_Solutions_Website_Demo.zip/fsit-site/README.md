# FS IT Solutions Website — Demo

A responsive, self-contained static storefront with sample catalogue, browser-local demo inventory editor, cart, and email-based order and contact enquiries.

## Preview
Open `index.html` in your browser. No installation required.

## Publish with GitHub Pages
1. Create a public GitHub repository (e.g. `fsit-solutions`).
2. Upload **index.html** and **README.md** to the repository root (not the ZIP itself).
3. Open repository Settings → Pages → Build and deployment → Source: Deploy from a branch.
4. Select branch `main`, folder `/(root)` and save.
5. Wait for the Pages workflow to finish and use the URL shown in Settings → Pages.

## Important limitations
- This is a working **static demo**, not a secure production ecommerce application.
- Product management uses browser localStorage, not a database, and is not secure.
- There is no account authentication, order database, inventory synchronization, or live PayFast checkout.
- Forms and checkout open the visitor's email app; they do not submit to a server.
- Product names and prices are illustrative and must be replaced with real inventory.
- To accept PayFast payments securely, build a server-side checkout and PayFast ITN verification with merchant credentials stored only on the server. GitHub Pages cannot host this backend.
